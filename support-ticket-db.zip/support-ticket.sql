/*
 Navicat Premium Data Transfer

 Source Server         : MySQL 8.0 Local
 Source Server Type    : MySQL
 Source Server Version : 80030 (8.0.30)
 Source Host           : localhost:3306
 Source Schema         : support-ticket

 Target Server Type    : MySQL
 Target Server Version : 80030 (8.0.30)
 File Encoding         : 65001

 Date: 25/07/2023 08:18:33
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for client
-- ----------------------------
DROP TABLE IF EXISTS `client`;
CREATE TABLE `client`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `linkedin` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `instagram` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `website` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of client
-- ----------------------------
INSERT INTO `client` VALUES (1, 'Bank Sumsel Babel', 'Sumatera', '121323425', NULL, '', '', '', NULL, '2023-07-19 13:14:22');
INSERT INTO `client` VALUES (2, 'Bank Jateng', 'Jawa Tengah', '122135443', NULL, '', '', '', NULL, '2023-07-20 13:59:29');
INSERT INTO `client` VALUES (3, 'Bank Lampung', '<p>Lampung</p>', '021123214', NULL, '', '', '', '2023-07-20 14:05:11', '2023-07-20 14:05:11');
INSERT INTO `client` VALUES (4, 'Universitas Terbuka', '<p>Jakarta</p>', '022912383712', NULL, '', '', '', '2023-07-20 14:07:53', '2023-07-20 14:07:53');
INSERT INTO `client` VALUES (5, 'Bank Sulsebar', '<p>Sulawesi</p>', '0212381474', NULL, '', '', '', '2023-07-20 14:08:23', '2023-07-20 14:08:23');

-- ----------------------------
-- Table structure for documents
-- ----------------------------
DROP TABLE IF EXISTS `documents`;
CREATE TABLE `documents`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of documents
-- ----------------------------
INSERT INTO `documents` VALUES (1, 'BPP', NULL, NULL);
INSERT INTO `documents` VALUES (2, 'FSD', NULL, NULL);
INSERT INTO `documents` VALUES (3, 'BRD', NULL, NULL);
INSERT INTO `documents` VALUES (4, 'UAT Script', NULL, NULL);
INSERT INTO `documents` VALUES (5, 'BAST', NULL, NULL);

-- ----------------------------
-- Table structure for failed_jobs
-- ----------------------------
DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE `failed_jobs`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `failed_jobs_uuid_unique`(`uuid` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of failed_jobs
-- ----------------------------

-- ----------------------------
-- Table structure for kategori
-- ----------------------------
DROP TABLE IF EXISTS `kategori`;
CREATE TABLE `kategori`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of kategori
-- ----------------------------
INSERT INTO `kategori` VALUES (1, 'Solutions', NULL, NULL);
INSERT INTO `kategori` VALUES (2, 'Consulting', NULL, NULL);
INSERT INTO `kategori` VALUES (3, 'Training', NULL, NULL);
INSERT INTO `kategori` VALUES (4, 'Research', NULL, NULL);

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations`  (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 20 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of migrations
-- ----------------------------
INSERT INTO `migrations` VALUES (1, '2014_10_12_000000_create_users_table', 1);
INSERT INTO `migrations` VALUES (2, '2014_10_12_100000_create_password_resets_table', 1);
INSERT INTO `migrations` VALUES (3, '2019_08_19_000000_create_failed_jobs_table', 1);
INSERT INTO `migrations` VALUES (4, '2019_12_14_000001_create_personal_access_tokens_table', 1);
INSERT INTO `migrations` VALUES (5, '2023_01_13_040751_create_clients_table', 1);
INSERT INTO `migrations` VALUES (6, '2023_01_13_041426_create_products_table', 1);
INSERT INTO `migrations` VALUES (7, '2023_01_13_060215_create_projects_table', 1);
INSERT INTO `migrations` VALUES (8, '2023_01_13_063827_create_documents_table', 1);
INSERT INTO `migrations` VALUES (9, '2023_01_13_063931_create_project_documents_table', 1);
INSERT INTO `migrations` VALUES (10, '2023_01_13_064025_create_kategori_table', 1);
INSERT INTO `migrations` VALUES (11, '2023_01_30_045214_create_tickets_table', 1);
INSERT INTO `migrations` VALUES (12, '2023_02_07_042140_create_ticket_status_table', 1);
INSERT INTO `migrations` VALUES (13, '2023_07_21_041258_add_no_ticket_to_tickets', 2);
INSERT INTO `migrations` VALUES (14, '2023_07_21_041923_remove_no_ticket_from_tickets', 3);
INSERT INTO `migrations` VALUES (15, '2023_07_21_042115_add_no_ticket_to_tickets', 4);
INSERT INTO `migrations` VALUES (16, '2023_07_21_043215_remove_no_ticket_from_tickets', 5);
INSERT INTO `migrations` VALUES (17, '2023_07_21_043254_add_no_ticket_to_tickets', 6);
INSERT INTO `migrations` VALUES (18, '2023_07_21_092950_add_new_columns_to_client', 7);
INSERT INTO `migrations` VALUES (19, '2023_07_22_085813_add_status_to_tickets', 8);

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets`  (
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`) USING BTREE
) ENGINE = InnoDB CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of password_resets
-- ----------------------------

-- ----------------------------
-- Table structure for personal_access_tokens
-- ----------------------------
DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE `personal_access_tokens`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint UNSIGNED NOT NULL,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `personal_access_tokens_token_unique`(`token` ASC) USING BTREE,
  INDEX `personal_access_tokens_tokenable_type_tokenable_id_index`(`tokenable_type` ASC, `tokenable_id` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of personal_access_tokens
-- ----------------------------

-- ----------------------------
-- Table structure for product
-- ----------------------------
DROP TABLE IF EXISTS `product`;
CREATE TABLE `product`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nama` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `id_kategori` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of product
-- ----------------------------
INSERT INTO `product` VALUES (1, 'Aplikasi TKB', 1, 1, NULL, NULL);
INSERT INTO `product` VALUES (2, 'Aplikasi TKB', 3, 2, NULL, '2023-07-19 12:07:38');
INSERT INTO `product` VALUES (5, 'Aplikasi LMS', 3, 3, '2023-07-21 02:21:43', '2023-07-21 02:21:43');
INSERT INTO `product` VALUES (6, 'Aplikasi TKB', 1, 5, '2023-07-21 07:59:37', '2023-07-21 07:59:37');

-- ----------------------------
-- Table structure for project
-- ----------------------------
DROP TABLE IF EXISTS `project`;
CREATE TABLE `project`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `client_id` bigint UNSIGNED NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `start_project` date NOT NULL,
  `finish_project` date NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of project
-- ----------------------------
INSERT INTO `project` VALUES (1, 1, 1, '2023-07-21', '2023-08-30', NULL, '2023-07-21 07:41:54');
INSERT INTO `project` VALUES (3, 2, 2, '2023-02-15', '2023-02-28', NULL, NULL);
INSERT INTO `project` VALUES (7, 3, 5, '2023-07-21', '2023-07-30', '2023-07-21 02:23:31', '2023-07-21 02:23:31');

-- ----------------------------
-- Table structure for projectdocuments
-- ----------------------------
DROP TABLE IF EXISTS `projectdocuments`;
CREATE TABLE `projectdocuments`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `project_id` bigint UNSIGNED NOT NULL,
  `document_id` bigint UNSIGNED NOT NULL,
  `file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 1 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of projectdocuments
-- ----------------------------

-- ----------------------------
-- Table structure for ticket_statuses
-- ----------------------------
DROP TABLE IF EXISTS `ticket_statuses`;
CREATE TABLE `ticket_statuses`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `status` enum('pending','to do','on progress','testing','staging','done') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL,
  `ticket_id` bigint UNSIGNED NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of ticket_statuses
-- ----------------------------
INSERT INTO `ticket_statuses` VALUES (1, 'pending', 'Harap Tunggu Admin akan Assign ke IT Teknisi', 1, '2023-07-21 06:45:31', '2023-07-21 06:45:31');
INSERT INTO `ticket_statuses` VALUES (2, 'pending', 'Harap Tunggu Admin akan Assign ke IT Teknisi', 2, '2023-07-21 07:45:52', '2023-07-21 07:45:52');
INSERT INTO `ticket_statuses` VALUES (3, 'to do', 'IT Teknisi sudah ditentukan oleh Admin, Tiket akan segera dikerjakan.', 2, '2023-07-21 07:48:48', '2023-07-21 07:48:48');
INSERT INTO `ticket_statuses` VALUES (4, 'to do', 'IT Teknisi sudah ditentukan oleh Admin, Tiket akan segera dikerjakan.', 1, '2023-07-21 07:51:54', '2023-07-21 07:51:54');
INSERT INTO `ticket_statuses` VALUES (5, 'on progress', 'Aplikasi sedang dalam perbaikan <b>Bug</b> dan <b>Error</b>', 2, '2023-07-21 09:17:13', '2023-07-21 09:17:13');
INSERT INTO `ticket_statuses` VALUES (6, 'testing', '<p>Aplikasi sedang dilakukan pengujian oleh QA</p>', 2, '2023-07-21 09:18:07', '2023-07-21 09:18:07');
INSERT INTO `ticket_statuses` VALUES (7, 'done', '<p>Aplikasi sudah selesai diperbaiki dan di uji</p>', 2, '2023-07-21 09:18:37', '2023-07-21 09:18:37');

-- ----------------------------
-- Table structure for tickets
-- ----------------------------
DROP TABLE IF EXISTS `tickets`;
CREATE TABLE `tickets`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `no_ticket` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` bigint UNSIGNED NOT NULL,
  `client_id` bigint UNSIGNED NOT NULL,
  `issue` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `file` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `tickets_no_ticket_unique`(`no_ticket` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 3 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of tickets
-- ----------------------------
INSERT INTO `tickets` VALUES (1, 'TICKET-00001', 5, 3, '<p>Terdapat <b>Error</b> dibagian menu <i>Monitoring Progres</i></p>', 'documents/byuDk6tAWufnl6C9SsAftZT4NsPt2mWw4bQvWe5N.pdf', 3, 'close', '2023-07-21 06:45:31', '2023-07-22 09:43:59');
INSERT INTO `tickets` VALUES (2, 'TICKET-00002', 1, 1, '<p>Ada beberapa Error pada aplikasi</p>', 'documents/fR9rLVMg7zPrdySnxKqZD9mPscbtKnEjVqwzxPqM.pdf', 2, 'open', '2023-07-21 07:45:52', '2023-07-21 07:48:48');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `client_id` bigint UNSIGNED NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `role` enum('admin','client','programmer') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'client',
  `tickets_count` int NOT NULL DEFAULT 0,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `users_email_unique`(`email` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_unicode_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', 'admin@gmail.com', '2023-02-17 01:44:12', '$2y$10$qvMhRsAZsiB6F5vLp6VK0e4Aw8ssKhFTia.QundSeTM0aWwgK.AOO', NULL, NULL, NULL, 'admin', 0, NULL, NULL, NULL);
INSERT INTO `users` VALUES (2, 'Haikal', 'haikal@gmail.com', '2023-02-17 01:44:12', '$2y$10$nmAmo0yAec/qpXi.HNH.bOtoB1HIffZrMEKuEWKQuP7Kw4CraNX02', NULL, NULL, NULL, 'programmer', 0, NULL, NULL, '2023-07-19 15:14:41');
INSERT INTO `users` VALUES (3, 'Rifqi', 'rifqi@gmail.com', '2023-02-17 01:44:12', '$2y$10$STMwE4guxz/VSIHyjt323.ZyOAwguroqotIdh6b3UNIbp.ucgLwwa', NULL, NULL, NULL, 'programmer', 0, NULL, NULL, NULL);
INSERT INTO `users` VALUES (4, 'Arif', 'arif@bankjateng.com', '2023-02-17 01:44:12', '$2y$10$iXnUSIEChkng6F4ZVTNxsOZe9AsxnkUYabUkWeX1.yVYGyRx4DPk.', NULL, 2, NULL, 'client', 0, NULL, NULL, '2023-07-20 14:09:52');
INSERT INTO `users` VALUES (6, 'Wisnu', 'wisnu@sumselbabel.com', '2023-07-19 00:00:00', '$2y$10$0.dK/c8tFcfSFaTJfmdu5.V/9AFXlnQzOzlOXu7xYUry41nnePc9K', 'images/f41gsOxVdduHHI6QPJL4cHAlGlJun8cq8PYpG1d4.jpg', 1, NULL, 'client', 0, NULL, '2023-07-19 13:08:24', '2023-07-20 14:40:37');
INSERT INTO `users` VALUES (8, 'Adit', 'Adit@banklampung.com', '2023-07-19 15:06:09', '$2y$10$CAu6iXCNB7vc7KTWkCZ.dOZNuBfFA1Z2mWtznRESv/aulPYQ98nU2', NULL, 3, NULL, 'client', 0, NULL, NULL, '2023-07-20 14:31:37');

SET FOREIGN_KEY_CHECKS = 1;
